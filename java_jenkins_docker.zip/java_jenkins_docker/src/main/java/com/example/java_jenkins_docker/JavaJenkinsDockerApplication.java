package com.example.java_jenkins_docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaJenkinsDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaJenkinsDockerApplication.class, args);
	}

}
