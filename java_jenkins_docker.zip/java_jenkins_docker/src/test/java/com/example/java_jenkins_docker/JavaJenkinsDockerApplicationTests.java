package com.example.java_jenkins_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaJenkinsDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
